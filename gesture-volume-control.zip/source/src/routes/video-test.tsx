import { createFileRoute } from "@tanstack/react-router";
import { useRef } from "react";

export const Route = createFileRoute("/video-test")({
  component: VideoTest,
  head: () => ({
    meta: [
      { title: "Video Audio Test | Gesture Volume Control" },
      {
        name: "description",
        content:
          "Minimal HTML5 video test page for diagnosing whether uploaded MP4 files play audio in the browser.",
      },
      { property: "og:title", content: "Video Audio Test" },
      {
        property: "og:description",
        content:
          "Minimal HTML5 video test page for diagnosing MP4 audio playback in the browser.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

function VideoTest() {
  const videoRef = useRef<HTMLVideoElement>(null);

  return (
    <main className="mx-auto flex min-h-screen max-w-2xl flex-col items-start gap-6 p-8">
      <h1 className="text-2xl font-bold">Video Audio Test</h1>
      <p className="text-sm text-muted-foreground">
        No gesture detection, no wrappers, no React state. Pick an MP4 and press play.
      </p>

      <input
        type="file"
        accept="video/*"
        onChange={(e) => {
          const file = e.target.files?.[0];
          const video = videoRef.current;
          if (!file || !video) return;

          video.src = URL.createObjectURL(file);
          video.muted = false;
          video.volume = 1;
          video.load();
        }}
      />

      <video
        ref={videoRef}
        controls
        playsInline
        className="w-full rounded-lg bg-black"
      />
    </main>
  );
}
