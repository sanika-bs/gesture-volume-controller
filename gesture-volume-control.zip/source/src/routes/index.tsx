import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Gesture Volume Control — Pinch to Adjust" },
      {
        name: "description",
        content:
          "Touchless volume control in your browser: pinch your thumb and index finger to adjust audio volume in real time using MediaPipe hand tracking.",
      },
      { property: "og:title", content: "Gesture Volume Control — Pinch to Adjust" },
      {
        property: "og:description",
        content:
          "Touchless volume control in your browser: pinch your thumb and index finger to adjust audio volume in real time using MediaPipe hand tracking.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

// Hand landmark connections (MediaPipe Hands topology)
const HAND_CONNECTIONS: [number, number][] = [
  [0, 1], [1, 2], [2, 3], [3, 4],
  [0, 5], [5, 6], [6, 7], [7, 8],
  [5, 9], [9, 10], [10, 11], [11, 12],
  [9, 13], [13, 14], [14, 15], [15, 16],
  [13, 17], [17, 18], [18, 19], [19, 20],
  [0, 17],
];

const SAMPLE_AUDIO =
  "https://cdn.pixabay.com/download/audio/2022/03/15/audio_1718e49cb1.mp3?filename=lofi-study-112191.mp3";

type MediaKind = "audio" | "video";

function Index() {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const mediaVideoRef = useRef<HTMLVideoElement | null>(null);
  const rafRef = useRef<number | null>(null);
  const landmarkerRef = useRef<any>(null);
  const objectUrlRef = useRef<string | null>(null);

  const [status, setStatus] = useState("Click Start to enable your webcam");
  const [running, setRunning] = useState(false);
  const [volume, setVolume] = useState(100);
  const [distance, setDistance] = useState(0);
  const [handDetected, setHandDetected] = useState(false);
  const [mediaSrc, setMediaSrc] = useState<string>(SAMPLE_AUDIO);
  const [mediaKind, setMediaKind] = useState<MediaKind>("audio");
  const [mediaStatus, setMediaStatus] = useState<string>("");
  const [muted, setMuted] = useState(false);

  const currentMediaEl = (): HTMLMediaElement | null =>
    mediaKind === "audio" ? audioRef.current : mediaVideoRef.current;

  useEffect(() => {
    const el = currentMediaEl();
    if (!el) return;
    el.volume = volume / 100;
  }, [volume, mediaKind, mediaSrc]);

  const logMediaState = (label: string, el: HTMLMediaElement | null) => {
    if (!el) return;
    // eslint-disable-next-line no-console
    console.log(label, {
      muted: el.muted,
      defaultMuted: el.defaultMuted,
      volume: el.volume,
      paused: el.paused,
      readyState: el.readyState,
    });
  };

  const handleLoadedMetadata = () => {
    const el = currentMediaEl();
    if (!el) return;
    el.defaultMuted = false;
    el.muted = false;
    el.volume = 1.0;
    setVolume(100);
    setMuted(false);
    logMediaState("[media] loadedmetadata", el);
  };

  const handleMediaVolumeChange = () => {
    const el = currentMediaEl();
    if (!el) return;
    setMuted(el.muted);
    setVolume(Math.round(el.volume * 100));
  };

  const toggleMute = async () => {
    const el = currentMediaEl();
    if (!el) return;

    if (el.muted) {
      el.muted = false;
      el.defaultMuted = false;
      el.volume = 1.0;
      setVolume(100);
      setMuted(false);
      try {
        await el.play();
      } catch (err) {
        console.warn("[media] play after unmute failed", err);
      }
      logMediaState("[media] unmute clicked", el);
      return;
    }

    el.muted = true;
    setMuted(true);
    logMediaState("[media] mute clicked", el);
  };

  const stop = () => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = null;
    const stream = videoRef.current?.srcObject as MediaStream | null;
    stream?.getTracks().forEach((t) => t.stop());
    if (videoRef.current) videoRef.current.srcObject = null;
    setRunning(false);
    setHandDetected(false);
    setStatus("Stopped");
  };

  const start = async () => {
    try {
      setStatus("Loading hand-tracking model…");
      const url = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/vision_bundle.mjs";
      const vision: any = await import(/* @vite-ignore */ url);
      const filesetResolver = await vision.FilesetResolver.forVisionTasks(
        "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm"
      );
      const handLandmarker = await vision.HandLandmarker.createFromOptions(filesetResolver, {
        baseOptions: {
          modelAssetPath:
            "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task",
          delegate: "GPU",
        },
        runningMode: "VIDEO",
        numHands: 1,
      });
      landmarkerRef.current = handLandmarker;

      setStatus("Requesting webcam…");
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480 },
        audio: false,
      });
      const video = videoRef.current!;
      video.srcObject = stream;
      await video.play();

      setRunning(true);
      setStatus("Tracking — pinch to adjust volume");

      const canvas = canvasRef.current!;
      const ctx = canvas.getContext("2d")!;
      let lastTs = -1;

      const loop = () => {
        if (!videoRef.current || !landmarkerRef.current) return;
        const v = videoRef.current;
        const w = v.videoWidth;
        const h = v.videoHeight;
        if (w && h) {
          if (canvas.width !== w) canvas.width = w;
          if (canvas.height !== h) canvas.height = h;
          const ts = performance.now();
          if (ts !== lastTs) {
            lastTs = ts;
            const result = landmarkerRef.current.detectForVideo(v, ts);
            ctx.clearRect(0, 0, w, h);

            if (result.landmarks && result.landmarks.length > 0) {
              const lm = result.landmarks[0];
              setHandDetected(true);

              ctx.strokeStyle = "rgba(56, 189, 248, 0.9)";
              ctx.lineWidth = 3;
              for (const [a, b] of HAND_CONNECTIONS) {
                ctx.beginPath();
                ctx.moveTo(lm[a].x * w, lm[a].y * h);
                ctx.lineTo(lm[b].x * w, lm[b].y * h);
                ctx.stroke();
              }
              ctx.fillStyle = "#fff";
              for (const p of lm) {
                ctx.beginPath();
                ctx.arc(p.x * w, p.y * h, 4, 0, Math.PI * 2);
                ctx.fill();
              }

              const thumb = lm[4];
              const index = lm[8];
              const tx = thumb.x * w;
              const ty = thumb.y * h;
              const ix = index.x * w;
              const iy = index.y * h;

              ctx.fillStyle = "#f43f5e";
              ctx.beginPath();
              ctx.arc(tx, ty, 10, 0, Math.PI * 2);
              ctx.fill();
              ctx.beginPath();
              ctx.arc(ix, iy, 10, 0, Math.PI * 2);
              ctx.fill();

              ctx.strokeStyle = "#f59e0b";
              ctx.lineWidth = 4;
              ctx.beginPath();
              ctx.moveTo(tx, ty);
              ctx.lineTo(ix, iy);
              ctx.stroke();

              const wrist = lm[0];
              const midMcp = lm[9];
              const handSize =
                Math.hypot((wrist.x - midMcp.x) * w, (wrist.y - midMcp.y) * h) || 1;
              const rawDist = Math.hypot(tx - ix, ty - iy);
              const normalized = rawDist / handSize;

              const minN = 0.3;
              const maxN = 2.2;
              const clamped = Math.max(minN, Math.min(maxN, normalized));
              const vol = Math.round(((clamped - minN) / (maxN - minN)) * 100);

              setDistance(Math.round(rawDist));
              setVolume(vol);
            } else {
              setHandDetected(false);
            }
          }
        }
        rafRef.current = requestAnimationFrame(loop);
      };
      rafRef.current = requestAnimationFrame(loop);
    } catch (err: any) {
      console.error(err);
      setStatus("Error: " + (err?.message ?? String(err)));
      setRunning(false);
    }
  };

  useEffect(() => {
    return () => stop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const setNewMedia = (url: string, kind: MediaKind, label: string) => {
    if (objectUrlRef.current) {
      try { URL.revokeObjectURL(objectUrlRef.current); } catch { /* noop */ }
    }
    objectUrlRef.current = url.startsWith("blob:") ? url : null;
    setMuted(false);
    setVolume(100);
    setMediaKind(kind);
    setMediaSrc(url);
    setMediaStatus(label);
  };

  const onFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    const isVideo = f.type.startsWith("video/") || /\.(mp4|mov|webm|m4v|ogv)$/i.test(f.name);
    const isAudio = f.type.startsWith("audio/") || /\.(mp3|wav|ogg|m4a|aac|flac|opus)$/i.test(f.name);
    if (isVideo) {
      setNewMedia(URL.createObjectURL(f), "video", `Loaded video: ${f.name}`);
    } else if (isAudio) {
      setNewMedia(URL.createObjectURL(f), "audio", `Loaded audio: ${f.name}`);
    } else {
      setMediaStatus("Unsupported file format. Please upload an audio or video file.");
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="mx-auto max-w-6xl px-6 py-10">
        <header className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Gesture Volume Control
          </h1>
          <p className="mt-2 text-muted-foreground">
            Pinch your thumb and index finger to control the media volume — no touching required.
          </p>
        </header>

        <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
          <div className="rounded-2xl border border-border bg-card p-4 shadow-sm">
            <div className="relative aspect-[4/3] w-full overflow-hidden rounded-xl bg-black">
              <video
                ref={videoRef}
                className="absolute inset-0 h-full w-full -scale-x-100 object-cover"
                playsInline
                muted
              />
              <canvas
                ref={canvasRef}
                className="absolute inset-0 h-full w-full -scale-x-100"
              />
              {!running && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/60 text-center text-white">
                  <div>
                    <p className="text-lg font-semibold">Webcam is off</p>
                    <p className="mt-1 text-sm opacity-80">Click Start to begin tracking</p>
                  </div>
                </div>
              )}
              {running && (
                <div className="absolute left-3 top-3 rounded-full bg-black/60 px-3 py-1 text-xs font-medium text-white">
                  {handDetected ? "Hand detected" : "Show your hand"}
                </div>
              )}
            </div>

            <div className="mt-4 flex flex-wrap items-center gap-3">
              {!running ? (
                <button
                  onClick={start}
                  className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition hover:bg-primary/90"
                >
                  Start camera
                </button>
              ) : (
                <button
                  onClick={stop}
                  className="rounded-md bg-destructive px-4 py-2 text-sm font-medium text-destructive-foreground transition hover:bg-destructive/90"
                >
                  Stop
                </button>
              )}
              <span className="text-sm text-muted-foreground">{status}</span>
            </div>
          </div>

          <div className="flex flex-col gap-6">
            <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
              <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                Volume
              </h2>
              <div className="mt-3 flex items-end gap-3">
                <span className="text-5xl font-bold tabular-nums">{volume}</span>
                <span className="mb-2 text-muted-foreground">%</span>
              </div>
              <div className="mt-4 h-3 w-full overflow-hidden rounded-full bg-muted">
                <div
                  className="h-full rounded-full bg-primary transition-[width] duration-100"
                  style={{ width: `${volume}%` }}
                />
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div className="rounded-lg bg-muted/60 p-3">
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">
                    Pinch distance
                  </div>
                  <div className="mt-1 font-semibold tabular-nums">{distance}px</div>
                </div>
                <div className="rounded-lg bg-muted/60 p-3">
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">
                    Status
                  </div>
                  <div className="mt-1 font-semibold">
                    {handDetected ? "Tracking" : running ? "Waiting" : "Idle"}
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
              <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                Media
              </h2>
              {mediaKind === "audio" ? (
                <audio
                  ref={audioRef}
                  src={mediaSrc}
                  controls
                  loop
                  crossOrigin="anonymous"
                  onLoadedMetadata={handleLoadedMetadata}
                  onVolumeChange={handleMediaVolumeChange}
                  className="mt-3 w-full"
                />
              ) : (
                <video
                  ref={mediaVideoRef}
                  src={mediaSrc}
                  controls
                  loop
                  playsInline
                  onLoadedMetadata={handleLoadedMetadata}
                  onVolumeChange={handleMediaVolumeChange}
                  className="mt-3 w-full rounded-lg bg-black"
                />
              )}
              <div className="mt-3 flex items-center gap-3">
                <button
                  type="button"
                  onClick={toggleMute}
                  className="rounded-md border border-border bg-background px-3 py-1.5 text-sm font-medium hover:bg-muted"
                >
                  {muted ? "Unmute" : "Mute"}
                </button>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={volume}
                  onChange={(e) => setVolume(Number(e.target.value))}
                  className="flex-1 accent-primary"
                  aria-label="Volume"
                />
                <span className="w-10 text-right text-sm tabular-nums text-muted-foreground">
                  {volume}%
                </span>
              </div>
              <label className="mt-3 block text-sm text-muted-foreground">
                Or load your own audio or video file:
                <input
                  type="file"
                  accept="audio/*,video/*"
                  onChange={onFile}
                  className="mt-2 block w-full text-sm text-foreground file:mr-3 file:rounded-md file:border-0 file:bg-primary file:px-3 file:py-1.5 file:text-sm file:font-medium file:text-primary-foreground hover:file:bg-primary/90"
                />
              </label>
              {mediaStatus && (
                <p className="mt-2 text-xs text-muted-foreground">{mediaStatus}</p>
              )}
            </div>

            <div className="rounded-2xl border border-border bg-card p-6 text-sm shadow-sm">
              <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                How to use
              </h2>
              <ol className="mt-3 list-decimal space-y-1 pl-5 text-muted-foreground">
                <li>Click Start and allow webcam access.</li>
                <li>Show one hand to the camera, palm facing you.</li>
                <li>Pinch thumb + index finger to lower volume, open them to raise it.</li>
                <li>Press play on the media to hear it change in real time.</li>
              </ol>
              <p className="mt-3 text-xs text-muted-foreground">
                Note: browsers can't control system volume for security reasons, so this demo
                controls the in-page media player instead.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
