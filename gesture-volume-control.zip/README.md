# Gesture Volume Control

Touchless volume control: pinch your thumb and index finger in front of your webcam
to adjust the volume of the in-page audio/video player in real time, using MediaPipe
hand tracking.

Two ways to run it:

## Option A — Standalone (easiest, no install)

1. Open `standalone/index.html` in Chrome or Edge (double-click it).
2. Click **Start camera** and allow webcam access.
3. Pinch thumb + index finger to lower volume; open them to raise it.

Requires an internet connection the first time (the hand-tracking model loads from a CDN).
Note: some browsers block webcam access on `file://` pages — if that happens, use
Option B, or serve the file locally (`npx serve standalone`).

## Option B — Full web app (React + TanStack Start)

Requirements: Node.js 20+ (or Bun).

```bash
npm install
npm run dev
```

Then open the printed local URL (usually http://localhost:5173 or :8080).

Source code for the app lives in `src/`:
- `src/routes/index.tsx` — the gesture volume control page
- `src/routes/video-test.tsx` — minimal video playback test page
